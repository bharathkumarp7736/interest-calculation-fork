# Contributing Guidelines
1. Fork the repository.
2. Make your changes in a separate branch.
3. Create a pull request.

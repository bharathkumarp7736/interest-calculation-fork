# Interest Calculation Project
This project calculates simple interest using a Bash script.
